
'use strict';

var notification = '     '  + 
 '   <div class="ui blue tiny compact floating message">  '  + 
 '   		<div>  '  + 
 '   			<i class="circular inverted yellow info icon"></i>  '  + 
 '   			<span style="margin-right: 0.5rem" id="sticky_notifications">Hello peer! Welcome to the new Peer Query, Click <a href="/a"><em>here</em></a> to see what this update includes.</span>  '  + 
 '   			<i class="ui fitted link times icon"></i>  '  + 
 '   		</div>  '  + 
 '  	</div>  ' ;  

module.exports = notification;