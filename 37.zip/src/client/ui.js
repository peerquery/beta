import 'semantic-ui-css/semantic.min.css';
import '../configs/global.css';
//import '../configs/global.js';
import $ from 'jquery';
window.jQuery = $;
window.$ = $;
import 'semantic-ui-css/semantic.min.js';

//well, this is weird. to be improved to 'import'
const config = require(__dirname + '/../configs/config');

$(document).ready(function() {
    
	const login_url = "https://v2.steemconnect.com/oauth2/authorize?client_id=" +
			//"peerquery.app" +
			config.sc2_app_name +
			"&redirect_uri=http%3A%2F%2F" + window.location.hostname + "%2Flogin" +
			//"&scope=vote,comment,custom_json" +
			"&scope=" + config.sc2_scope +
			"&state=%2F" + window.location.pathname.substring(1);
			
					
	//initialize auth system
	
	(async () => {
		
		//check is session storage is supported or not. if not - alert the user that their browser is NOT supported
		if (typeof(Storage) == "undefined") { alert('Sorry your browser is NOT supported. Please upgrade or switch to a modern broswer.'); return };
	
		//check to see if user is logged in. if not exist, else continue
		if(!active_user || active_user == '') return;
	
		//check if access_token exists in session storage. if yes, return the value and exists. else continue
		if (sessionStorage.access_token) { const access_token = sessionStorage.access_token; /*return access_token;*/; return };
	
		//if not, ping server for decrypted access_token. use key to decrypt data. store decrypted data in session storage
		try{
		
			const auth = await Promise.resolve($.get("/api/private/auth" ));
			//console.log(access_token);
			sessionStorage.access_token = auth.access_token;
		
		} catch(err) {
			console.log(err);
			alert('Sorry, could not auth your account. Consider signing in again');
			window.location.href = '/login';
		}
	
	})()
			
			
	$('#navbarLoginButton').attr('href', login_url);
	
	$('.ui.menu .ui.dropdown').dropdown({
		on: 'hover'
	});
	
	$('.ui.menu a.item').on('click', function() {
		$(this)
			.addClass('active')
			.siblings()
			.removeClass('active');
	});

	$('.ui.menu .ui.dropdown').dropdown({on: 'hover'});
	
	$('.ui.menu a.item').on('click', function() {
        $(this)
        .addClass('active')
        .siblings()
        .removeClass('active');
    });
	
	$('.ui.dropdown').dropdown();
	
	
	
	$( "#item-container" ).on('click', '.pop', function() {
		var el = this;
	
		jQuery('.ui.modal').modal('show');
	
		$('.ui.modal')
			.modal({
			onShow    : function(){
				//window.alert('Showing modal!!!');
				//console.log(this); //works but rather only logs the real modal itself!
				document.getElementById('modal_href').href = "/@" + el.dataset.account + "/" + el.dataset.permlink;
				document.getElementById('modal_title').innerHTML = el.dataset.title;
				document.getElementById('modal_author').innerHTML = "@" + el.dataset.account;
				document.getElementById('modal_content').innerHTML = el.dataset.body;
				return false;
			}
		}).modal('show');
	
	});
	
	
	
	$('img').each(function() {
		if (!this.complete || typeof this.naturalWidth == "undefined" || this.naturalWidth == 0) {
			// image was broken, replace with your new image
			this.src = '/assets/images/placeholder.png';
		}
	});
	
	
});

	
	console.log('%cSTOP! PROCEED WITH CAUTION!', 'color: red; font-size: 30px; font-weight: bold;');
	console.log('%cThis is the developer console!!!', 'color: red; font-size: 20px; font-weight: bold;');
	console.log('%cANY ACTIVITY HERE COULD POTENTIALLY COMPROMISE YOUR ACCOUNT!!!', 'color: red; font-size: 20px; font-weight: bold;');
