
"use strict";

var utils = require('./utils');

module.export = {
	
	post: function(text) {
		
		
		return html;
	}
	
}
