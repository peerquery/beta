
'use strict';

var content = require('./content');
	
module.exports = async function (app) {
	
	content(app);
	
}
	