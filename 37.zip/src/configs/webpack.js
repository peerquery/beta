
var paths = [
	'./src/app.js',
	''
];


module.exports = {paths, };
